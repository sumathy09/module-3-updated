package stepdef;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class FormPageFactory {

	WebDriver wd;

	// initiating Elements
	public FormPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	@FindBy(name = "userName")
	@CacheLookup
	WebElement uname;

	@FindBy(name = "city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name = "password")
	@CacheLookup
	WebElement password;
	
	@FindBy(name = "gender")
	@CacheLookup
	List<WebElement>  radioButton;
	
	@FindBy(name = "lang")
	@CacheLookup
	List<WebElement> checkBox;
	
	@FindBy(name = "textarea")
	@CacheLookup
	WebElement textarea;
	
	
	@FindBy(name = "country")
	@CacheLookup
	WebElement country;
	//Select country=new Select(wd.findElement(By.name("country")));
	
	@FindBy(name = "number")
	@CacheLookup
	WebElement number;
	
	@FindBy(name = "email")
	@CacheLookup
	WebElement email;
	
	
	@FindBy(name = "mobilenumber")
	@CacheLookup
	WebElement mobilenumber;
	
	 
	@FindBy(xpath="/html/body/form/input[14]")
	@CacheLookup
	WebElement button;

	
	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

	public WebElement getUname() {
		return uname;
	}

	public void setUname(String userName) {
		System.out.println(uname.getAttribute("type"));
		this.uname.sendKeys(userName);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String cityName) {

		this.city.sendKeys(cityName);
	}
	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}


	public List<WebElement> getRadioButton() {
		return radioButton;
	}

	public void setRadioButton(int radioBtn) {	
		if(radioBtn==1) {
		radioButton.get(radioBtn).click();
		}
		else {
			radioButton.get(radioBtn).click();
		}
		
	}

	public List<WebElement> getCheckBox() {
		return checkBox;
	}

	public void setCheckBox(List<String> checkBx) {
		for(String s:checkBx) {
			if(s.equalsIgnoreCase("English")) {
		checkBox.get(0).click();
		}else if(s.equalsIgnoreCase("Telugu")) {
			checkBox.get(1).click();
			}else if(s.equalsIgnoreCase("Tamil")) {
				checkBox.get(2).click();
				}else {
					
				}
			
		}
	}

	public WebElement getTextArea() {
		return textarea;
	}

	public void setTextArea(String txtarea) {
		this.textarea.sendKeys(txtarea);
	}

	
	
	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String ctry) {

		//((Select) country).selectByVisibleText(ctry);
		
	}
	
	public void select(String coun) {
		Select count=new Select(wd.findElement(By.name("country")));
		count.selectByVisibleText(coun);
	}

	public WebElement getNumber() {
		return number;
	}

	public void setNumber(String num) {
		this.number.sendKeys(num);
	}
	
	
	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String emailId) {
		this.email.sendKeys(emailId);
	}

	public WebElement getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenum) {
		this.mobilenumber.sendKeys(mobilenum);
	}


	
	
	
}
