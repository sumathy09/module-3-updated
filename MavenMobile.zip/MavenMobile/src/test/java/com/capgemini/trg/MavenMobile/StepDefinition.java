package com.capgemini.trg.MavenMobile;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinition {
	List<String> l;
	@Given("^The mobile numbers are$")
	public void the_mobile_numbers_are(DataTable arg1) throws Throwable {

		l = new ArrayList<String>();
		l = arg1.asList(String.class);
		for (String list : l) {
			Pattern p = Pattern.compile("[6-9][0-9]{9}");
			Matcher mat = p.matcher(list);
			boolean s = mat.find() && mat.group().equals(list);
			if (s)
				System.out.println("valid Number");
			
			else
				System.out.println("Invalid Number");
		}
	}

	@Then("^add to list$")
	public void add_to_list() throws Throwable {
		System.out.println("Datas are added");
		//l.stream().forEach(System.out::println);
	}

}
