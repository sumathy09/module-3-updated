$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capgemini/trg/MavenMobile/file.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author sumathy"
    }
  ],
  "line": 2,
  "name": "Mobile Number",
  "description": "",
  "id": "mobile-number",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Mobile validation",
  "description": "",
  "id": "mobile-number;mobile-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "The mobile numbers are",
  "rows": [
    {
      "cells": [
        "9564564554"
      ],
      "line": 7
    },
    {
      "cells": [
        "7755556564"
      ],
      "line": 8
    },
    {
      "cells": [
        "6767676766"
      ],
      "line": 9
    },
    {
      "cells": [
        "5676767677"
      ],
      "line": 10
    },
    {
      "cells": [
        "09676"
      ],
      "line": 11
    },
    {
      "cells": [
        "56"
      ],
      "line": 12
    }
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "add to list",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_mobile_numbers_are(DataTable)"
});
formatter.result({
  "duration": 104178725,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.add_to_list()"
});
formatter.result({
  "duration": 50457,
  "status": "passed"
});
});