$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/login.feature");
formatter.feature({
  "line": 1,
  "name": "login application",
  "description": "",
  "id": "login-application",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "invalid password",
  "description": "",
  "id": "login-application;invalid-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "check for username and password",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "valid username invalid password",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_username_and_password()"
});
formatter.result({
  "duration": 36353287540,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.valid_username_invalid_password()"
});
formatter.result({
  "duration": 15767551017,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 8667286861,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "invalid username",
  "description": "",
  "id": "login-application;invalid-username",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "check for username and password",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "invalid username valid password",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_username_and_password()"
});
formatter.result({
  "duration": 20081541541,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.invalid_username_valid_password()"
});
formatter.result({
  "duration": 17372156285,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 6276169950,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Empty case",
  "description": "",
  "id": "login-application;empty-case",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "check for username and password",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "username and password is empty",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_username_and_password()"
});
formatter.result({
  "duration": 11045602074,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.username_and_password_is_empty()"
});
formatter.result({
  "duration": 1289244356,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 7086356472,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "valid credentials",
  "description": "",
  "id": "login-application;valid-credentials",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "check for username and password",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "username and password is valid",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "user navigate to next page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_username_and_password()"
});
formatter.result({
  "duration": 12139405758,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.username_and_password_is_valid()"
});
formatter.result({
  "duration": 1733422770,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_navigate_to_next_page()"
});
formatter.result({
  "duration": 38423986687,
  "status": "passed"
});
formatter.uri("features/register.feature");
formatter.feature({
  "line": 1,
  "name": "form validation",
  "description": "",
  "id": "form-validation",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 2,
  "name": "city name validation",
  "description": "",
  "id": "form-validation;city-name-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 3,
  "name": "check for cityname",
  "keyword": "Given "
});
formatter.step({
  "line": 4,
  "name": "city name is empty",
  "keyword": "When "
});
formatter.step({
  "line": 5,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition2.check_for_cityname()"
});
formatter.result({
  "duration": 67061427032,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.city_name_is_empty()"
});
formatter.result({
  "duration": 17215237020,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.print_error_message()"
});
formatter.result({
  "duration": 7069446542,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "password validation",
  "description": "",
  "id": "form-validation;password-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "check for password",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "password is empty",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition2.check_for_password()"
});
formatter.result({
  "duration": 17162582625,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.password_is_empty()"
});
formatter.result({
  "duration": 19688535703,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.print_error_message()"
});
formatter.result({
  "duration": 9413068542,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "gender validation",
  "description": "",
  "id": "form-validation;gender-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "check for gender",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "gender is empty",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition2.check_for_gender()"
});
formatter.result({
  "duration": 15713887403,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.gender_is_empty()"
});
formatter.result({
  "duration": 1266431100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.print_error_message()"
});
formatter.result({
  "duration": 7762804996,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "language validation",
  "description": "",
  "id": "form-validation;language-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "check for language",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "language is empty",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition2.check_for_language()"
});
formatter.result({
  "duration": 16300651228,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.language_is_empty()"
});
formatter.result({
  "duration": 1195386913,
  "error_message": "java.lang.NullPointerException\r\n\tat com.cg.project.POMMaven.PageFactoryReg.setLanguage(PageFactoryReg.java:91)\r\n\tat com.cg.project.POMMaven.StepDefinition2.language_is_empty(StepDefinition2.java:97)\r\n\tat ✽.When language is empty(features/register.feature:19)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDefinition2.print_error_message()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 22,
  "name": "country validation",
  "description": "",
  "id": "form-validation;country-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "check for country",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "country name is empty",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition2.check_for_country()"
});
formatter.result({
  "duration": 30262279371,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.country_name_is_empty()"
});
formatter.result({
  "duration": 17023722774,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.print_error_message()"
});
formatter.result({
  "duration": 12894743993,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "success scenario",
  "description": "",
  "id": "form-validation;success-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "check for inputs",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "all are correct",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "print success message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition2.check_for_inputs()"
});
formatter.result({
  "duration": 28453606434,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.all_are_correct()"
});
formatter.result({
  "duration": 15523619898,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.print_success_message()"
});
formatter.result({
  "duration": 67361764008,
  "error_message": "org.openqa.selenium.SessionNotCreatedException: session not created\nfrom disconnected: received Inspector.detached event\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.44.609538 (b655c5a60b0b544917107a59d4153d4bf78e1b90),platform\u003dWindows NT 6.3.9600 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 42.88 seconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027LENOVO\u0027, ip: \u0027127.0.0.1\u0027, os.name: \u0027Windows 8.1\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.3\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: driver.version: ChromeDriver\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$new$0(JsonWireProtocolResponse.java:53)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$getResponseFunction$2(JsonWireProtocolResponse.java:91)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.lambda$createSession$0(ProtocolHandshake.java:123)\r\n\tat java.util.stream.ReferencePipeline$3$1.accept(Unknown Source)\r\n\tat java.util.Spliterators$ArraySpliterator.tryAdvance(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.forEachWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyIntoWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyInto(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.wrapAndCopyInto(Unknown Source)\r\n\tat java.util.stream.FindOps$FindOp.evaluateSequential(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.evaluate(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.findFirst(Unknown Source)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:126)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:73)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:136)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:212)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:130)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:181)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:168)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:123)\r\n\tat com.cg.project.POMMaven.StepDefinition2.print_success_message(StepDefinition2.java:158)\r\n\tat ✽.Then print success message(features/register.feature:30)\r\n",
  "status": "failed"
});
});