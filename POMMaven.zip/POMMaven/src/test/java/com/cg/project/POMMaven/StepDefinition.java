package com.cg.project.POMMaven;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
  

public class StepDefinition {
	private PageFactoryForm fact;
	private WebDriver driver;
	@Given("^check for username and password$")
	public void check_for_username_and_password() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryForm(driver); 
    	driver.get("D:\\eclipse programs\\POMMaven\\src\\test\\java\\login1.html");
	}

	@When("^valid username invalid password$")
	public void valid_username_invalid_password() throws Throwable {
	    fact.setUname("sumathy");
	    fact.setPassword("xyz");
	    fact.setButton();
	}

	@Then("^error message$")
	public void error_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@When("^invalid username valid password$")
	public void invalid_username_valid_password() throws Throwable {
	    fact.setUname("sumi");
	    fact.setPassword("abcd");
	    fact.setButton();
	    
	}

	@When("^username and password is empty$")
	public void username_and_password_is_empty() throws Throwable {
		fact.setUname("");
	    fact.setPassword("");
	    fact.setButton();
	}

	@When("^username and password is valid$")
	public void username_and_password_is_valid() throws Throwable {
		fact.setUname("sumathy");
	    fact.setPassword("abcd");
	    fact.setButton();  
	}

	@Then("^user navigate to next page$")
	public void user_navigate_to_next_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryForm(driver); 
		 driver.get("D:\\\\eclipse programs\\\\POMMaven\\\\src\\\\test\\\\java\\\\basicform.html");
	}




}
