package com.cg.project.POMMaven;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition2 {
	private PageFactoryReg fact;
	private WebDriver driver;
	@Given("^check for cityname$")
	public void check_for_cityname() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryReg(driver); 
    	driver.get("D:\\eclipse programs\\POMMaven\\src\\test\\java\\basicform.html");
	}

	@When("^city name is empty$")
	public void city_name_is_empty() throws Throwable {
		fact.setCity("");
		fact.setButton();
	     
	}

	@Then("^print error message$")
	public void print_error_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	     	}

	@Given("^check for password$")
	public void check_for_password() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryReg(driver); 
    	driver.get("D:\\eclipse programs\\POMMaven\\src\\test\\java\\basicform.html");

		
	     	}

	@When("^password is empty$")
	public void password_is_empty() throws Throwable {
	     fact.setCity("chennai");
	     fact.setPassword("");
	     fact.setButton();
	}

	@Given("^check for gender$")
	public void check_for_gender() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryReg(driver); 
    	driver.get("D:\\eclipse programs\\POMMaven\\src\\test\\java\\basicform.html");

	     	}

	@When("^gender is empty$")
	public void gender_is_empty() throws Throwable {
		fact.setCity("chennai");
		fact.setPassword("abcd");
		fact.setRadioButton("");
		fact.setButton();
	     	}

	@Given("^check for language$")
	public void check_for_language() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryReg(driver); 
    	driver.get("D:\\eclipse programs\\POMMaven\\src\\test\\java\\basicform.html");

 	}

	@When("^language is empty$")
	public void language_is_empty() throws Throwable {
		fact.setCity("chennai");
		fact.setPassword("abcd");
		fact.setRadioButton("Male");
		
		List<Integer> lang = new ArrayList<Integer>();
		lang.add(null);
		fact.setLanguage(lang);
		fact.setButton();
		

	}

	@Given("^check for country$")
	public void check_for_country() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryReg(driver); 
    	driver.get("D:\\eclipse programs\\POMMaven\\src\\test\\java\\basicform.html");

	     
	}

	@When("^country name is empty$")
	public void country_name_is_empty() throws Throwable {
		fact.setCity("chennai");
		fact.setPassword("abcd");
		fact.setRadioButton("female");
		
		List<Integer> lang = new ArrayList<Integer>();
		lang.add(0);
		lang.add(1);
		fact.setLanguage(lang);
		fact.setCountry("select");
		fact.setButton();
		
	}

	@Given("^check for inputs$")
	public void check_for_inputs() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryReg(driver); 
    	driver.get("D:\\eclipse programs\\POMMaven\\src\\test\\java\\basicform.html");

	     
	}

	@When("^all are correct$")
	public void all_are_correct() throws Throwable {
		fact.setCity("chennai");
		fact.setPassword("abcd");
		fact.setRadioButton("female");
		
		List<Integer> lang = new ArrayList<Integer>();
		lang.add(0);
		lang.add(1);
		lang.add(2);
		fact.setLanguage(lang);
		fact.setCountry("US");
		fact.setButton();
	}

	@Then("^print success message$")
	public void print_success_message() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
    	driver= new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	fact=new PageFactoryReg(driver); 
    	driver.get("D:\\eclipse programs\\POMMaven\\src\\test\\java\\basicform.html");
	     
	}


}
