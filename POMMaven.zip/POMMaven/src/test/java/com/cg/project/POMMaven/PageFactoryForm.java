package com.cg.project.POMMaven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
 

public class PageFactoryForm {
	WebDriver wd;

	// initiating Elements
	public PageFactoryForm(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	@FindBy(name = "username")
	@CacheLookup
	WebElement uname;
	
	@FindBy(name = "password")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath="/html/body/form/input[3]")
	@CacheLookup
	WebElement button;

	public WebElement getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname.sendKeys(uname);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}
}
