package com.cg.project.POMMaven;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFactoryReg {
	WebDriver wd;
	// initiating Elements
	public PageFactoryReg(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	@FindBy(name = "city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name = "password")
	@CacheLookup
	WebElement password;
	
	@FindBy(name = "gender")
	@CacheLookup
	WebElement radioButton;
	
	@FindBy(name="lang")
	@CacheLookup
	List<WebElement> language;
	
	@FindBy(name = "country")
	@CacheLookup
	WebElement country ;
	
	@FindBy(xpath="/html/body/form/input[9]")
	@CacheLookup
	WebElement button;
	
	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
 
	 
	public WebElement getRadioButton() {
		return radioButton;
	}

	public void setRadioButton(String radioButton) {
		if(radioButton.equalsIgnoreCase("male"))
		{
			this.radioButton.click();
		}
		else if(radioButton.equalsIgnoreCase("female"))
		{
			this.radioButton.click();
		}
		else
		{
			
		}
	}  
	
	 
	public List<WebElement> getLanguage() {
		return language;
		
	}
public void setLanguage(List<Integer> lang) {
	Iterator<Integer> i= lang.iterator();
	
	while(i.hasNext()) {
		int a= i.next();
		
		if(a == 1)
		{
			this.language.get(0).click();
		}
		else if(a == 2)
		{
			this.language.get(1).click();
		}
		else if(a == 3)
		{
			this.language.get(2).click();
		}
		else
		{
			
		}
	}}

public WebElement getCountry() {
	return country;
}

public void setCountry(String ctry) {

	Select count=new Select(wd.findElement(By.name("country")));
	count.selectByVisibleText(ctry);
	
}


	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}
}
