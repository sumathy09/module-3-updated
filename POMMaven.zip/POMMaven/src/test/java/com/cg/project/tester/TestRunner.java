package com.cg.project.tester;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"usage","html:html-op/html-output"}, features= {"classpath:features"},glue= {"com.cg.project.POMMaven"})
public class TestRunner {

}
