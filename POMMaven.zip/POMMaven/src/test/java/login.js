function validate() {
	if(document.form1.username.value=="")
	{
    alert("please fill the name");
	}
	else if(document.form1.password.value=="")
		{
		alert("please fill the password");
		}
	else if(document.form1.username.value=="sumi")
		{
		alert("enter the correct user name");
		}
	else if(document.form1.password.value=="xyz")
		{
		alert("enter the correct password");
		}
	else 
		{
		alert("success");
		}	
	}