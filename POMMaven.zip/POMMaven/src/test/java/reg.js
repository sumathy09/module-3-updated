function validate() {
	if(document.form.city.value=="")
	{
    alert("please fill the city");
	}
	else if(document.form.password.value=="")
		{
		alert("please fill the password");
		}
	else if(document.form.gender.value=="")
	{
	alert("please fill the gender");
	}
	else if(document.form.lang.value==null)
	{
	alert("please fill the language");
	}
	else if(document.form.country.value=="select")
	{
	alert("please fill the country");
	}
	else
	{
	alert("successful");
	}
} 