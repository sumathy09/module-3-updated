package com.capgemini.trg.MavenProj2;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinition1 {
	@Given("^enter username and password$")
	public void enter_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("fd");
	    //throw new PendingException();
	}

	@Then("^navigate to main page$")
	public void navigate_to_main_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	 

}
