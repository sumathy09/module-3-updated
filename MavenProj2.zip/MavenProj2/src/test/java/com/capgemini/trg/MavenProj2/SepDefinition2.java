package com.capgemini.trg.MavenProj2;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SepDefinition2 {
	@Given("^user is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Registration Page");
	    //throw new PendingException();
	}

	@When("^user enters the username$")
	public void user_enters_the_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Enters the username");
	    //throw new PendingException();
	}

	@When("^user enters the password$")
	public void user_enters_the_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Enters the password");
	    //throw new PendingException();
	}

	@When("^user enters the mobileNo$")
	public void user_enters_the_mobileNo() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Enters mobileNo");
	    //throw new PendingException();
	}

	@When("^user enters the emailId$")
	public void user_enters_the_emailId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Enters emailId");
	    //throw new PendingException();
	}

	@Then("^Registration Successfull$")
	public void registration_Successfull() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("success");
	    //throw new PendingException();
	}

}
