package com.capgemini.trg.MavenProj2;

 

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(plugin = {"usage" ,"html:Htmlop/html-output"},glue= {"com.capgemini.trg.MavenProj2"})
public class TestRunner {

}
