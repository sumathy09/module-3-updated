$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capgemini/trg/MavenProj2/selenium.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Sumathy Sankar"
    }
  ],
  "line": 2,
  "name": "Login to main page",
  "description": "For valid username and password navigate to main page",
  "id": "login-to-main-page",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 7,
  "name": "Login Successfull",
  "description": "",
  "id": "login-to-main-page;login-successfull",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "enter username and password",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "navigate to main page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition1.enter_username_and_password()"
});
formatter.result({
  "duration": 98712261,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition1.navigate_to_main_page()"
});
formatter.result({
  "duration": 13948,
  "status": "passed"
});
formatter.uri("com/capgemini/trg/MavenProj2/selenium2.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Sumathy Sankar"
    }
  ],
  "line": 2,
  "name": "Registration",
  "description": "For valid username and password navigate to main page",
  "id": "registration",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 7,
  "name": "Registration with valid credentials",
  "description": "",
  "id": "registration;registration-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "user is on registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "user enters the username",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "user enters the password",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "user enters the mobileNo",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "user enters the emailId",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Registration Successfull",
  "keyword": "Then "
});
formatter.match({
  "location": "SepDefinition2.user_is_on_registration_page()"
});
formatter.result({
  "duration": 103383,
  "status": "passed"
});
formatter.match({
  "location": "SepDefinition2.user_enters_the_username()"
});
formatter.result({
  "duration": 41435,
  "status": "passed"
});
formatter.match({
  "location": "SepDefinition2.user_enters_the_password()"
});
formatter.result({
  "duration": 38974,
  "status": "passed"
});
formatter.match({
  "location": "SepDefinition2.user_enters_the_mobileNo()"
});
formatter.result({
  "duration": 61537,
  "status": "passed"
});
formatter.match({
  "location": "SepDefinition2.user_enters_the_emailId()"
});
formatter.result({
  "duration": 53333,
  "status": "passed"
});
formatter.match({
  "location": "SepDefinition2.registration_Successfull()"
});
formatter.result({
  "duration": 53743,
  "status": "passed"
});
});