package com.capgemini.trg.tester;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty","html:html-output"}, features= {"classpath:features"} ,glue="com.capgemini.trg.POM1")


public class RunTestForm {

}
