package com.capgemini.trg.POM1;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
 
import org.openqa.selenium.support.PageFactory;
 

public class FormPgFactory {
 
	WebDriver wd;

	// initiating Elements
	public FormPgFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	@FindBy(name = "userName")
	@CacheLookup
	WebElement uname;

	@FindBy(name = "password")
	@CacheLookup
	WebElement password;
 
	@FindBy(xpath="/html/body/form/input[13]")
	@CacheLookup
	WebElement button;
 
	@FindBy(name="gender")
	@CacheLookup
	List<WebElement> radioButton;
	
	@FindBy(name="lang")
	@CacheLookup
	List<WebElement> language;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;

	@FindBy(name="email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="mobile")
	@CacheLookup
	WebElement mobile;
	
	
	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

	public WebElement getUname() {
		return uname;
	}

	public void setUname(String uname) {
		 
		this.uname.sendKeys(uname);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		 
		this.password.sendKeys(password);
	}

	public List<WebElement> getRadioButton() {
		return radioButton;
	}

	public void setRadioButton(int radioBtn) {	
		
		radioButton.get(radioBtn).click();
	} 
	public List<WebElement> getLanguage() {
		return language;
		
	}
public void setLanguage(List<Integer> lang) {
	Iterator<Integer> i= lang.iterator();
	
	while(i.hasNext()) {
		int a= i.next();
		
		if(a == 1)
		{
			this.language.get(0).click();
		}
		else if(a == 2)
		{
			this.language.get(1).click();
		}
		else if(a == 3)
		{
			this.language.get(2).click();
		}
		else
		{
			
		}
		
			
	} }}
/* 
	
	   
public void setGender(String gender) {
		if(gender.equalsIgnoreCase("male"))
		{
			this.gender.get(0).click();
		}
		else if(gender.equalsIgnoreCase("female"))
		{
			this.gender.get(1).click();
		}
		else
		{
			
		}
	} 
 
 
	  
}*/
