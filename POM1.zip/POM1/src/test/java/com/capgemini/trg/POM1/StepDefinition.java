package com.capgemini.trg.POM1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
 

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	private FormPgFactory fact;
	private WebDriver driver;

	@Given("^check for username$")
	public void check_for_username() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new FormPgFactory(driver);
		driver.get("D:\\Hema_contents\\java_jee\\STS\\POM1\\src\\test\\java\\Basicform.html");
		 
		}

	@When("^user name is empty$")
	public void user_name_is_empty() throws Throwable {
		fact.setUname("");
		fact.setButton(); 
	}

	@Then("^print error message for user name$")
	public void print_error_message_for_user_name() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close(); 
	}

	@Given("^check for city name$")
	public void check_for_city_name() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new FormPgFactory(driver);
		//driver.get("D:\\module 3\\Basicform.html");
		driver.get("D:\\Hema_contents\\java_jee\\STS\\POM1\\src\\test\\java\\Basicform.html");
	}

	@When("^city name is empty$")
	public void city_name_is_empty() throws Throwable {
		fact.setUname("sumathy");
		fact.setCity("chennai");
		fact.setButton();
		
		
	}

	@Then("^print error message for city name$")
	public void print_error_message_for_city_name() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@Given("^check for password$")
	public void check_for_password() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new FormPgFactory(driver);
		driver.get("D:\\Hema_contents\\java_jee\\STS\\POM1\\src\\test\\java\\Basicform.html");
	}

	@When("^password is empty$")
	public void password_is_empty() throws Throwable {
		fact.setUname("sumathyssssssssss");
		fact.setCity("");
		fact.setPassword("hello");
		fact.setButton(); 
	}

	@Then("^print error message for password$")
	public void print_error_message_for_password() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@Given("^click for radio buttons$")
	public void click_for_radio_buttons() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			fact = new FormPgFactory(driver);
			driver.get("D:\\Hema_contents\\java_jee\\STS\\POM1\\src\\test\\java\\Basicform.html");
	}

	@When("^gender is empty$")
	public void gender_is_empty() throws Throwable {
		fact.setUname("sumathyssssssssss");
		fact.setCity("chennai");
		fact.setPassword("");
		fact.setRadioButton(1);
		fact.setButton();
	}

	@Then("^print error message for gender$")
	public void print_error_message_for_gender() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@Given("^Tick for check box$")
	public void tick_for_check_box() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			fact = new FormPgFactory(driver);
			driver.get("D:\\Hema_contents\\java_jee\\STS\\POM1\\src\\test\\java\\Basicform.html");
	}

	@When("^check box is empty$")
	public void check_box_is_empty() throws Throwable {
		fact.setUname("sumathyssssssssss");
		fact.setCity("chennai");
		fact.setPassword("");
		fact.setRadioButton(1);
		  
		List<Integer> lang = new ArrayList<Integer>();
		
		lang.add(1);
		lang.add(2);
		 
		fact.setLanguage(lang);
		fact.setButton();
	}

	@Then("^print error message for language$")
	public void print_error_message_for_language() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	   	}

	 

	@Given("^check for the mobile$")
	public void check_for_the_mobile() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
		 
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			fact = new FormPgFactory(driver);
			driver.get("D:\\Hema_contents\\java_jee\\STS\\POM1\\src\\test\\java\\Basicform.html");
	   	}

	@When("^mobile is empty$")
	public void mobile_is_empty() throws Throwable {
		fact.setUname("sumathy");
		fact.setCity("chennai");
		fact.setPassword("");
		fact.setRadioButton(1);
		List<Integer> lang = new ArrayList<Integer>();
		lang.add(1);
		lang.add(2);
		lang.add(3); 
		fact.setLanguage(lang);
		fact.setMobile("9945455443");
		fact.setButton();
	}

	@Then("^print error message for mobile$")
	public void print_error_message_for_mobile() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@Given("^check for the email$")
	public void check_for_the_email() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new FormPgFactory(driver);
	//	driver.get("D:\\\\Hema_contents\\\\java_jee\\\\STS\\\\POM1\\\\src\\\\test\\\\java\\\\com\\\\capgemini\\\\trg\\\\POM1\\\\Basicform.html"); 
		//driver.get("D:\\module 3\\Basicform.html");
		driver.get("D:\\Hema_contents\\java_jee\\STS\\POM1\\src\\test\\java\\Basicform.html");
	}

	@When("^email is empty$")
	public void email_is_empty() throws Throwable {
		fact.setUname("sumathy");
		fact.setCity("");
		fact.setPassword("gv");
		fact.setRadioButton(1);
		 
		fact.setMobile("9945455443");
		fact.setEmail("sumathy@gmail");
		fact.setButton();
	}

	@Then("^print error message for email$")
	public void print_error_message_for_email() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}


}
