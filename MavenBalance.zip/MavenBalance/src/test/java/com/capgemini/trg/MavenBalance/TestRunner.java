package com.capgemini.trg.MavenBalance;

 

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(plugin = {"usage" ,"html:Htmlop/html-output"})
public class TestRunner {

}

