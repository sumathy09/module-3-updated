package com.capgemini.trg.MavenBalance;

import static org.junit.Assert.assertTrue;

import java.util.Scanner;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	Customer c=new Customer();
	 Scanner sc=new Scanner(System.in);
	@Given("^Enter All the details$")
	public void enter_All_the_details() throws Throwable {
		System.out.println("Enter the name");
		c.setName(sc.next());
		System.out.println("Enter the accNo");
		c.setAccNo(sc.nextInt());
		System.out.println("Enter phoneNo");
		c.setMobileNum(sc.nextInt());
		System.out.println("Enter the balance");
		c.setBalance(sc.nextDouble());
	}

	@When("^check the balance$")
	public void check_the_balance() throws Throwable {
		 Assert.assertTrue( c.getBalance()>=500);
	    
	}

	@Then("^print all the details$")
	public void print_all_the_details() throws Throwable {
		
	    System.out.println(c);
	}

	@When("^balance is low$")
	public void balance_is_low() throws Throwable {
		 Assert.assertTrue( c.getBalance()<500);
	}

	
	@Then("^print error message$")
	public void print_error_message() throws Throwable {
	     System.out.println("error");
	}

}
