package com.capgemini.trg.MavenBalance;

public class Customer {
private String name;
private Integer mobileNum;
private Double balance;
private Integer accNo;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getMobileNum() {
	return mobileNum;
}
public void setMobileNum(Integer mobileNum) {
	this.mobileNum = mobileNum;
}
public Double getBalance() {
	return balance;
}
public void setBalance(Double balance) {
	this.balance = balance;
}
public Integer getAccNo() {
	return accNo;
}
public void setAccNo(Integer accNo) {
	this.accNo = accNo;
}
public Customer(String name, Integer mobileNum, Double balance, Integer accNo) {
	super();
	this.name = name;
	this.mobileNum = mobileNum;
	this.balance = balance;
	this.accNo = accNo;
}
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Customer [name=" + name + ", mobileNum=" + mobileNum + ", balance=" + balance + ", accNo=" + accNo + "]";
}
}
