$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capgemini/trg/MavenBalance/features.feature");
formatter.feature({
  "line": 1,
  "name": "Checking Balance",
  "description": "",
  "id": "checking-balance",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Customer details",
  "description": "",
  "id": "checking-balance;customer-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "Enter All the details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_All_the_details()"
});
formatter.result({
  "duration": 25657507723,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "For correct ammount",
  "description": "",
  "id": "checking-balance;for-correct-ammount",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "check the balance",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "print all the details",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_the_balance()"
});
formatter.result({
  "duration": 331862,
  "error_message": "java.lang.NullPointerException\r\n\tat com.capgemini.trg.MavenBalance.StepDefinition.check_the_balance(StepDefinition.java:30)\r\n\tat ✽.When check the balance(com/capgemini/trg/MavenBalance/features.feature:7)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDefinition.print_all_the_details()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 10,
  "name": "for incorrect amount",
  "description": "",
  "id": "checking-balance;for-incorrect-amount",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "balance is low",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.balance_is_low()"
});
formatter.result({
  "duration": 196491,
  "error_message": "java.lang.NullPointerException\r\n\tat com.capgemini.trg.MavenBalance.StepDefinition.balance_is_low(StepDefinition.java:42)\r\n\tat ✽.When balance is low(com/capgemini/trg/MavenBalance/features.feature:11)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDefinition.print_error_message()"
});
formatter.result({
  "status": "skipped"
});
});