package com.capgemini.trg.MavenCalc;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinition {
	@Given("^Initializing the value$")
	public void initializing_the_value() throws Throwable {
	    System.out.println("values are:"); 
	}

	@Given("^value of (\\d+) and (\\d+)$")
	public void value_of_and(int arg1, int arg2) throws Throwable {
	     System.out.println("The value of a = " +arg1+ "The value of b =" +arg2);
	}

	@Then("^add (\\d+) and(\\d+)$")
	public void add_and(int arg1, int arg2) throws Throwable {
		System.out.println("Addition ="+(arg1+arg2));   
	}

	@Then("^sub (\\d+) and(\\d+)$")
	public void sub_and(int arg1, int arg2) throws Throwable {
		System.out.println("subtraction=" +(arg1-arg2));
	}

	@Then("^mul (\\d+) and(\\d+)$")
	public void mul_and(int arg1, int arg2) throws Throwable {
		System.out.println("multiplication="+(arg1*arg2));
	}

	@Then("^divide (\\d+) and(\\d+)$")
	public void divide_and(int arg1, int arg2) throws Throwable {
		System.out.println("division="+(arg1/arg2));  
	}


}
