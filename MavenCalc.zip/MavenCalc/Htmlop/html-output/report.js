$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capgemini/trg/MavenCalc/selenium.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Sumathy"
    }
  ],
  "line": 2,
  "name": "Calculator",
  "description": "",
  "id": "calculator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 7,
  "name": "Addition",
  "description": "",
  "id": "calculator;addition",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 8,
  "name": "value of \u003ca\u003e and \u003cb\u003e",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "add \u003ca\u003e and\u003cb\u003e",
  "keyword": "Then "
});
formatter.examples({
  "line": 10,
  "name": "",
  "description": "",
  "id": "calculator;addition;",
  "rows": [
    {
      "cells": [
        "a",
        "b"
      ],
      "line": 11,
      "id": "calculator;addition;;1"
    },
    {
      "cells": [
        "2",
        "3"
      ],
      "line": 12,
      "id": "calculator;addition;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Initializing the value",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.initializing_the_value()"
});
formatter.result({
  "duration": 102497659,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Addition",
  "description": "",
  "id": "calculator;addition;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 8,
  "name": "value of 2 and 3",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "add 2 and3",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 9
    },
    {
      "val": "3",
      "offset": 15
    }
  ],
  "location": "StepDefinition.value_of_and(int,int)"
});
formatter.result({
  "duration": 1752837,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 4
    },
    {
      "val": "3",
      "offset": 9
    }
  ],
  "location": "StepDefinition.add_and(int,int)"
});
formatter.result({
  "duration": 100502,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 15,
  "name": "Subtraction",
  "description": "",
  "id": "calculator;subtraction",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 16,
  "name": "value of \u003ca\u003e and \u003cb\u003e",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "sub \u003ca\u003e and\u003cb\u003e",
  "keyword": "Then "
});
formatter.examples({
  "line": 19,
  "name": "",
  "description": "",
  "id": "calculator;subtraction;",
  "rows": [
    {
      "cells": [
        "a",
        "b"
      ],
      "line": 20,
      "id": "calculator;subtraction;;1"
    },
    {
      "cells": [
        "10",
        "3"
      ],
      "line": 21,
      "id": "calculator;subtraction;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Initializing the value",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.initializing_the_value()"
});
formatter.result({
  "duration": 50867,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "Subtraction",
  "description": "",
  "id": "calculator;subtraction;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 16,
  "name": "value of 10 and 3",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "sub 10 and3",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "10",
      "offset": 9
    },
    {
      "val": "3",
      "offset": 16
    }
  ],
  "location": "StepDefinition.value_of_and(int,int)"
});
formatter.result({
  "duration": 131268,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "10",
      "offset": 4
    },
    {
      "val": "3",
      "offset": 10
    }
  ],
  "location": "StepDefinition.sub_and(int,int)"
});
formatter.result({
  "duration": 133729,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 23,
  "name": "Multiplication",
  "description": "",
  "id": "calculator;multiplication",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 24,
  "name": "value of \u003ca\u003e and \u003cb\u003e",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "mul \u003ca\u003e and\u003cb\u003e",
  "keyword": "Then "
});
formatter.examples({
  "line": 27,
  "name": "",
  "description": "",
  "id": "calculator;multiplication;",
  "rows": [
    {
      "cells": [
        "a",
        "b"
      ],
      "line": 28,
      "id": "calculator;multiplication;;1"
    },
    {
      "cells": [
        "12",
        "3"
      ],
      "line": 29,
      "id": "calculator;multiplication;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Initializing the value",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.initializing_the_value()"
});
formatter.result({
  "duration": 43482,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "Multiplication",
  "description": "",
  "id": "calculator;multiplication;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 24,
  "name": "value of 12 and 3",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "mul 12 and3",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "12",
      "offset": 9
    },
    {
      "val": "3",
      "offset": 16
    }
  ],
  "location": "StepDefinition.value_of_and(int,int)"
});
formatter.result({
  "duration": 109527,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "12",
      "offset": 4
    },
    {
      "val": "3",
      "offset": 10
    }
  ],
  "location": "StepDefinition.mul_and(int,int)"
});
formatter.result({
  "duration": 111988,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 31,
  "name": "Division",
  "description": "",
  "id": "calculator;division",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 32,
  "name": "value of \u003ca\u003e and \u003cb\u003e",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "divide \u003ca\u003e and\u003cb\u003e",
  "keyword": "Then "
});
formatter.examples({
  "line": 35,
  "name": "",
  "description": "",
  "id": "calculator;division;",
  "rows": [
    {
      "cells": [
        "a",
        "b"
      ],
      "line": 36,
      "id": "calculator;division;;1"
    },
    {
      "cells": [
        "6",
        "3"
      ],
      "line": 37,
      "id": "calculator;division;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Initializing the value",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.initializing_the_value()"
});
formatter.result({
  "duration": 40201,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "Division",
  "description": "",
  "id": "calculator;division;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 32,
  "name": "value of 6 and 3",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "divide 6 and3",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "6",
      "offset": 9
    },
    {
      "val": "3",
      "offset": 15
    }
  ],
  "location": "StepDefinition.value_of_and(int,int)"
});
formatter.result({
  "duration": 113218,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "6",
      "offset": 7
    },
    {
      "val": "3",
      "offset": 12
    }
  ],
  "location": "StepDefinition.divide_and(int,int)"
});
formatter.result({
  "duration": 138652,
  "status": "passed"
});
});