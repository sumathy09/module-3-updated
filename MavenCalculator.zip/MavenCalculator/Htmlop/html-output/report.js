$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capgemini/trg/MavenCalculator/file.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author  sumathy"
    }
  ],
  "line": 2,
  "name": "Calcualator",
  "description": "To perform Arithmetic operation",
  "id": "calcualator",
  "keyword": "Feature"
});
formatter.before({
  "duration": 4453053065,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "Getting Input from the User",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.getting_Input_from_the_User()"
});
formatter.result({
  "duration": 108548288,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Perform addition",
  "description": "",
  "id": "calcualator;perform-addition",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "Get the values of a and b",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "Print sum",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.get_the_values_of_a_and_b()"
});
formatter.result({
  "duration": 90246,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.print_sum()"
});
formatter.result({
  "duration": 34868,
  "status": "passed"
});
formatter.before({
  "duration": 9390191745,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "Getting Input from the User",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.getting_Input_from_the_User()"
});
formatter.result({
  "duration": 111578,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Perform subtraction",
  "description": "",
  "id": "calcualator;perform-subtraction",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "Get the values of a and b",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "Print sub",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.get_the_values_of_a_and_b()"
});
formatter.result({
  "duration": 144395,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.print_sub()"
});
formatter.result({
  "duration": 114449,
  "status": "passed"
});
