package com.capgemini.trg.MavenCalculator;

import java.util.Scanner;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinition {
	int a,b;
	@Before
    public void func() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the value of a");
	a=sc.nextInt();
	System.out.println("Enter the value of b");
	b=sc.nextInt();
	}
	@Given("^Getting Input from the User$")
	public void getting_Input_from_the_User() throws Throwable {
	     System.out.println("Getting inputs from the user");
	}

	@Given("^Get the values of a and b$")
	public void get_the_values_of_a_and_b() throws Throwable {
	    System.out.println("The values of a is :" +a); 
	    System.out.println("The value of b is :" +b);
	}

	@Then("^Print sum$")
	public void print_sum() throws Throwable {
		System.out.println("Addition ="+(a+b));    
	}

	@Then("^Print sub$")
	public void print_sub() throws Throwable {
		System.out.println("subtraction=" +(a-b));
	}

	@Then("^Print mul$")
	public void print_mul() throws Throwable {
		System.out.println("multiplication="+(a*b));
	}

	@Then("^Print div$")
	public void print_div() throws Throwable {
		System.out.println("division="+(a/b));  
	}


}
