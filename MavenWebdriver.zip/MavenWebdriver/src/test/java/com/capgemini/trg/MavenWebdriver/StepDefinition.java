package com.capgemini.trg.MavenWebdriver;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinition {
	@Given("^All Customer Details$")
	public void all_Customer_Details() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
    	 WebDriver wd=new ChromeDriver();
    	 wd.get("D:\\Hema_contents\\java_jee\\STS\\MavenWebdriver\\src\\main\\java\\com\\capgemini\\trg\\MavenWebdriver\\index.html");
    	 WebElement name = wd.findElement(By.name("firstname"));
    	// Pattern p = Pattern.compile("[6-9][0-9]{9}");
			//Matcher mat = p.matcher(name);
			//boolean s = mat.find() && mat.group().equals(name);
         name.sendKeys("Sumathy");  
         WebElement acNo= wd.findElement(By.name("account"));
         acNo.sendKeys("10032"); 
         WebElement balance= wd.findElement(By.name("balance"));
         balance.sendKeys("100"); 
         WebElement aathar= wd.findElement(By.name("aathar"));
         aathar.sendKeys("123625365162"); 
         WebElement gender= wd.findElement(By.name("group-1"));
         gender.click();
         WebElement lang = wd.findElement(By.name("option-1"));
         lang.click();
         WebElement drop = wd.findElement(By.name("deposit"));
         Select drop1=new Select(drop);
         drop1.selectByVisibleText("deposit");
        
         
         
	}

	@Then("^print Successfull registration$")
	public void print_Successfull_registration() throws Throwable {
	     System.out.println("success");
	}
}
