package com.capgemini.trg.MavenWebdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class App 
{
    public static void main( String[] args )
    {
    	 System.setProperty("webdriver.chrome.driver", "D:\\module 2\\chromedriver.exe");
    	 WebDriver wd=new ChromeDriver();
    	 wd.get("D:\\Hema_contents\\java_jee\\STS\\MavenWebdriver\\src\\main\\java\\com\\capgemini\\trg\\MavenWebdriver\\index.html");
    	 WebElement name = wd.findElement(By.name("firstname"));
         name.sendKeys("Sumathy");
        System.out.println(name.getAttribute("sumathy"));
         WebElement acNo= wd.findElement(By.name("account"));
         acNo.sendKeys("10032");
         WebElement balance= wd.findElement(By.name("balance"));
         balance.sendKeys("100"); 
         WebElement gender= wd.findElement(By.name("group-1"));
         gender.click();
         WebElement lang = wd.findElement(By.name("option-1"));
         lang.click();
         WebElement drop = wd.findElement(By.name("Deposit"));
         Select drop1=new Select(drop);
         drop1.selectByVisibleText("Deposit");  
         //WebElement TxtBoxContent = wd.findElement(By.id(“WebelementID”));

    }
}
 