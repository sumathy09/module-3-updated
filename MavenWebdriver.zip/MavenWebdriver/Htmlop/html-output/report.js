$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capgemini/trg/MavenWebdriver/features.feature");
formatter.feature({
  "line": 1,
  "name": "Bank Application",
  "description": "",
  "id": "bank-application",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 2,
  "name": "Registration Process",
  "description": "",
  "id": "bank-application;registration-process",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 3,
  "name": "All Customer Details",
  "keyword": "Given "
});
formatter.step({
  "line": 4,
  "name": "print Successfull registration",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.all_Customer_Details()"
});
formatter.result({
  "duration": 3963528858,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"name\",\"selector\":\"deposit\"}\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T521\u0027, ip: \u002710.219.34.229\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\sumsanka\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:50023}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 9bc29f63800e91229a8c85f49e9de4f1\n*** Element info: {Using\u003dname, value\u003ddeposit}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:322)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByName(RemoteWebDriver.java:400)\r\n\tat org.openqa.selenium.By$ByName.findElement(By.java:284)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:314)\r\n\tat com.capgemini.trg.MavenWebdriver.StepDefinition.all_Customer_Details(StepDefinition.java:36)\r\n\tat ✽.Given All Customer Details(com/capgemini/trg/MavenWebdriver/features.feature:3)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDefinition.print_Successfull_registration()"
});
formatter.result({
  "status": "skipped"
});
formatter.uri("com/capgemini/trg/MavenWebdriver/features1.feature");
formatter.feature({
  "line": 1,
  "name": "Validations For Creating Account",
  "description": "",
  "id": "validations-for-creating-account",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 2,
  "name": "For validating Name",
  "description": "",
  "id": "validations-for-creating-account;for-validating-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 3,
  "name": "The names are",
  "rows": [
    {
      "cells": [
        "Sumathy"
      ],
      "line": 4
    },
    {
      "cells": [
        "sumathy"
      ],
      "line": 5
    },
    {
      "cells": [
        "SUmathy"
      ],
      "line": 6
    },
    {
      "cells": [
        "ss"
      ],
      "line": 7
    }
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "add to the list",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 10,
  "name": "For validating Account Number",
  "description": "",
  "id": "validations-for-creating-account;for-validating-account-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "The mobile numbers are",
  "rows": [
    {
      "cells": [
        "9564564554"
      ],
      "line": 13
    },
    {
      "cells": [
        "7755556564"
      ],
      "line": 14
    },
    {
      "cells": [
        "6767676766"
      ],
      "line": 15
    },
    {
      "cells": [
        "5676767677"
      ],
      "line": 16
    },
    {
      "cells": [
        "09676"
      ],
      "line": 17
    },
    {
      "cells": [
        "56"
      ],
      "line": 18
    }
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "add to list",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 21,
  "name": "For validating balance",
  "description": "",
  "id": "validations-for-creating-account;for-validating-balance",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 22,
  "name": "The inputs are",
  "rows": [
    {
      "cells": [
        "900"
      ],
      "line": 23
    },
    {
      "cells": [
        "900.25"
      ],
      "line": 24
    },
    {
      "cells": [
        "0"
      ],
      "line": 25
    },
    {
      "cells": [
        "-200"
      ],
      "line": 26
    }
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 27,
  "name": "add to list",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 29,
  "name": "For validating aathar",
  "description": "",
  "id": "validations-for-creating-account;for-validating-aathar",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 30,
  "name": "The inputs are",
  "rows": [
    {
      "cells": [
        "985895885545"
      ],
      "line": 31
    },
    {
      "cells": [
        "000000000000"
      ],
      "line": 32
    },
    {
      "cells": [
        "194384"
      ],
      "line": 33
    },
    {
      "cells": [
        "-122121"
      ],
      "line": 34
    }
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 35,
  "name": "add to list",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});